# Definimos la ruta raiz de nuestro proyecto
import os
ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
ROOT_PATH = ROOT_PATH.split("notebooks")[0]